/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 1 "parser.y"

/*
 * PE3: C Symbol Table Builder
 * Bison parser with full symbol table population.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "symbol_table.h"

extern int yylex();
extern int yylineno;
extern char *yytext;
extern int  line_num;
extern int  col_num;

void yyerror(const char *s);
int  yylex_destroy(void);

static int syntax_error = 0;

/* ---------- helpers passed down during parsing ---------- */
/* current type context (base type + storage) */
static char   cur_base_type[64]  = "int";
static int    cur_is_pointer     = 0;
static StorageClass cur_storage  = STORAGE_AUTO;

/* small helper: duplicate a string (safe) */
static char *dupstr(const char *s) {
    char *r = malloc(strlen(s)+1);
    strcpy(r, s);
    return r;
}

/* ---- per-declarator temporary state ---- */
static int   decl_dims[MAX_DIMS];
static int   decl_ndim = 0;
static int   decl_ptr  = 0;
static char  decl_val[64] = "";

#line 113 "parser.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "parser.tab.h"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_TOKEN_IDENTIFIER = 3,           /* TOKEN_IDENTIFIER  */
  YYSYMBOL_TOKEN_INT_CONST = 4,            /* TOKEN_INT_CONST  */
  YYSYMBOL_TOKEN_FLOAT_CONST = 5,          /* TOKEN_FLOAT_CONST  */
  YYSYMBOL_TOKEN_CHAR_CONST = 6,           /* TOKEN_CHAR_CONST  */
  YYSYMBOL_TOKEN_STRING_LITERAL = 7,       /* TOKEN_STRING_LITERAL  */
  YYSYMBOL_TOKEN_INT = 8,                  /* TOKEN_INT  */
  YYSYMBOL_TOKEN_FLOAT = 9,                /* TOKEN_FLOAT  */
  YYSYMBOL_TOKEN_CHAR = 10,                /* TOKEN_CHAR  */
  YYSYMBOL_TOKEN_DOUBLE = 11,              /* TOKEN_DOUBLE  */
  YYSYMBOL_TOKEN_VOID = 12,                /* TOKEN_VOID  */
  YYSYMBOL_TOKEN_LONG = 13,                /* TOKEN_LONG  */
  YYSYMBOL_TOKEN_SHORT = 14,               /* TOKEN_SHORT  */
  YYSYMBOL_TOKEN_UNSIGNED = 15,            /* TOKEN_UNSIGNED  */
  YYSYMBOL_TOKEN_SIGNED = 16,              /* TOKEN_SIGNED  */
  YYSYMBOL_TOKEN_STRUCT = 17,              /* TOKEN_STRUCT  */
  YYSYMBOL_TOKEN_UNION = 18,               /* TOKEN_UNION  */
  YYSYMBOL_TOKEN_TYPEDEF = 19,             /* TOKEN_TYPEDEF  */
  YYSYMBOL_TOKEN_ENUM = 20,                /* TOKEN_ENUM  */
  YYSYMBOL_TOKEN_AUTO = 21,                /* TOKEN_AUTO  */
  YYSYMBOL_TOKEN_EXTERN = 22,              /* TOKEN_EXTERN  */
  YYSYMBOL_TOKEN_REGISTER = 23,            /* TOKEN_REGISTER  */
  YYSYMBOL_TOKEN_STATIC = 24,              /* TOKEN_STATIC  */
  YYSYMBOL_TOKEN_IF = 25,                  /* TOKEN_IF  */
  YYSYMBOL_TOKEN_ELSE = 26,                /* TOKEN_ELSE  */
  YYSYMBOL_TOKEN_DO = 27,                  /* TOKEN_DO  */
  YYSYMBOL_TOKEN_WHILE = 28,               /* TOKEN_WHILE  */
  YYSYMBOL_TOKEN_FOR = 29,                 /* TOKEN_FOR  */
  YYSYMBOL_TOKEN_SWITCH = 30,              /* TOKEN_SWITCH  */
  YYSYMBOL_TOKEN_CASE = 31,                /* TOKEN_CASE  */
  YYSYMBOL_TOKEN_DEFAULT = 32,             /* TOKEN_DEFAULT  */
  YYSYMBOL_TOKEN_BREAK = 33,               /* TOKEN_BREAK  */
  YYSYMBOL_TOKEN_CONTINUE = 34,            /* TOKEN_CONTINUE  */
  YYSYMBOL_TOKEN_RETURN = 35,              /* TOKEN_RETURN  */
  YYSYMBOL_TOKEN_SIZEOF = 36,              /* TOKEN_SIZEOF  */
  YYSYMBOL_TOKEN_PLUS = 37,                /* TOKEN_PLUS  */
  YYSYMBOL_TOKEN_MINUS = 38,               /* TOKEN_MINUS  */
  YYSYMBOL_TOKEN_STAR = 39,                /* TOKEN_STAR  */
  YYSYMBOL_TOKEN_SLASH = 40,               /* TOKEN_SLASH  */
  YYSYMBOL_TOKEN_PERCENT = 41,             /* TOKEN_PERCENT  */
  YYSYMBOL_TOKEN_INC = 42,                 /* TOKEN_INC  */
  YYSYMBOL_TOKEN_DEC = 43,                 /* TOKEN_DEC  */
  YYSYMBOL_TOKEN_EQ = 44,                  /* TOKEN_EQ  */
  YYSYMBOL_TOKEN_NE = 45,                  /* TOKEN_NE  */
  YYSYMBOL_TOKEN_LT = 46,                  /* TOKEN_LT  */
  YYSYMBOL_TOKEN_GT = 47,                  /* TOKEN_GT  */
  YYSYMBOL_TOKEN_LE = 48,                  /* TOKEN_LE  */
  YYSYMBOL_TOKEN_GE = 49,                  /* TOKEN_GE  */
  YYSYMBOL_TOKEN_AND = 50,                 /* TOKEN_AND  */
  YYSYMBOL_TOKEN_OR = 51,                  /* TOKEN_OR  */
  YYSYMBOL_TOKEN_NOT = 52,                 /* TOKEN_NOT  */
  YYSYMBOL_TOKEN_ASSIGN = 53,              /* TOKEN_ASSIGN  */
  YYSYMBOL_TOKEN_ADD_ASSIGN = 54,          /* TOKEN_ADD_ASSIGN  */
  YYSYMBOL_TOKEN_SUB_ASSIGN = 55,          /* TOKEN_SUB_ASSIGN  */
  YYSYMBOL_TOKEN_MUL_ASSIGN = 56,          /* TOKEN_MUL_ASSIGN  */
  YYSYMBOL_TOKEN_DIV_ASSIGN = 57,          /* TOKEN_DIV_ASSIGN  */
  YYSYMBOL_TOKEN_MOD_ASSIGN = 58,          /* TOKEN_MOD_ASSIGN  */
  YYSYMBOL_TOKEN_AND_ASSIGN = 59,          /* TOKEN_AND_ASSIGN  */
  YYSYMBOL_TOKEN_OR_ASSIGN = 60,           /* TOKEN_OR_ASSIGN  */
  YYSYMBOL_TOKEN_XOR_ASSIGN = 61,          /* TOKEN_XOR_ASSIGN  */
  YYSYMBOL_TOKEN_LSHIFT_ASSIGN = 62,       /* TOKEN_LSHIFT_ASSIGN  */
  YYSYMBOL_TOKEN_RSHIFT_ASSIGN = 63,       /* TOKEN_RSHIFT_ASSIGN  */
  YYSYMBOL_TOKEN_BIT_AND = 64,             /* TOKEN_BIT_AND  */
  YYSYMBOL_TOKEN_BIT_NOT = 65,             /* TOKEN_BIT_NOT  */
  YYSYMBOL_TOKEN_BIT_OR = 66,              /* TOKEN_BIT_OR  */
  YYSYMBOL_TOKEN_BIT_XOR = 67,             /* TOKEN_BIT_XOR  */
  YYSYMBOL_TOKEN_LSHIFT = 68,              /* TOKEN_LSHIFT  */
  YYSYMBOL_TOKEN_RSHIFT = 69,              /* TOKEN_RSHIFT  */
  YYSYMBOL_TOKEN_DOT = 70,                 /* TOKEN_DOT  */
  YYSYMBOL_TOKEN_ARROW = 71,               /* TOKEN_ARROW  */
  YYSYMBOL_TOKEN_QUESTION = 72,            /* TOKEN_QUESTION  */
  YYSYMBOL_TOKEN_SEMICOLON = 73,           /* TOKEN_SEMICOLON  */
  YYSYMBOL_TOKEN_COMMA = 74,               /* TOKEN_COMMA  */
  YYSYMBOL_TOKEN_LPAREN = 75,              /* TOKEN_LPAREN  */
  YYSYMBOL_TOKEN_RPAREN = 76,              /* TOKEN_RPAREN  */
  YYSYMBOL_TOKEN_LBRACE = 77,              /* TOKEN_LBRACE  */
  YYSYMBOL_TOKEN_RBRACE = 78,              /* TOKEN_RBRACE  */
  YYSYMBOL_TOKEN_LBRACKET = 79,            /* TOKEN_LBRACKET  */
  YYSYMBOL_TOKEN_RBRACKET = 80,            /* TOKEN_RBRACKET  */
  YYSYMBOL_TOKEN_COLON = 81,               /* TOKEN_COLON  */
  YYSYMBOL_YYACCEPT = 82,                  /* $accept  */
  YYSYMBOL_translation_unit = 83,          /* translation_unit  */
  YYSYMBOL_external_declaration = 84,      /* external_declaration  */
  YYSYMBOL_function_definition = 85,       /* function_definition  */
  YYSYMBOL_86_1 = 86,                      /* $@1  */
  YYSYMBOL_declarator_func = 87,           /* declarator_func  */
  YYSYMBOL_param_list_opt = 88,            /* param_list_opt  */
  YYSYMBOL_parameter_list = 89,            /* parameter_list  */
  YYSYMBOL_parameter_declaration = 90,     /* parameter_declaration  */
  YYSYMBOL_param_declarator = 91,          /* param_declarator  */
  YYSYMBOL_declaration = 92,               /* declaration  */
  YYSYMBOL_declaration_specifiers = 93,    /* declaration_specifiers  */
  YYSYMBOL_storage_class_specifier = 94,   /* storage_class_specifier  */
  YYSYMBOL_type_qualifier_list = 95,       /* type_qualifier_list  */
  YYSYMBOL_type_qualifier = 96,            /* type_qualifier  */
  YYSYMBOL_type_specifier = 97,            /* type_specifier  */
  YYSYMBOL_init_declarator_list = 98,      /* init_declarator_list  */
  YYSYMBOL_init_declarator = 99,           /* init_declarator  */
  YYSYMBOL_declarator = 100,               /* declarator  */
  YYSYMBOL_simple_declarator = 101,        /* simple_declarator  */
  YYSYMBOL_array_dims = 102,               /* array_dims  */
  YYSYMBOL_initializer_val = 103,          /* initializer_val  */
  YYSYMBOL_initializer_list_inner = 104,   /* initializer_list_inner  */
  YYSYMBOL_compound_statement = 105,       /* compound_statement  */
  YYSYMBOL_106_2 = 106,                    /* $@2  */
  YYSYMBOL_compound_statement_noenter = 107, /* compound_statement_noenter  */
  YYSYMBOL_block_item_list = 108,          /* block_item_list  */
  YYSYMBOL_block_item = 109,               /* block_item  */
  YYSYMBOL_statement = 110,                /* statement  */
  YYSYMBOL_labeled_statement = 111,        /* labeled_statement  */
  YYSYMBOL_constant_expression = 112,      /* constant_expression  */
  YYSYMBOL_expression_statement = 113,     /* expression_statement  */
  YYSYMBOL_selection_statement = 114,      /* selection_statement  */
  YYSYMBOL_iteration_statement = 115,      /* iteration_statement  */
  YYSYMBOL_for_init = 116,                 /* for_init  */
  YYSYMBOL_for_cond = 117,                 /* for_cond  */
  YYSYMBOL_for_step = 118,                 /* for_step  */
  YYSYMBOL_jump_statement = 119,           /* jump_statement  */
  YYSYMBOL_expression = 120,               /* expression  */
  YYSYMBOL_assignment_expression = 121,    /* assignment_expression  */
  YYSYMBOL_assignment_op = 122,            /* assignment_op  */
  YYSYMBOL_conditional_expression = 123,   /* conditional_expression  */
  YYSYMBOL_logical_or_expression = 124,    /* logical_or_expression  */
  YYSYMBOL_logical_and_expression = 125,   /* logical_and_expression  */
  YYSYMBOL_bitwise_or_expression = 126,    /* bitwise_or_expression  */
  YYSYMBOL_bitwise_xor_expression = 127,   /* bitwise_xor_expression  */
  YYSYMBOL_bitwise_and_expression = 128,   /* bitwise_and_expression  */
  YYSYMBOL_equality_expression = 129,      /* equality_expression  */
  YYSYMBOL_relational_expression = 130,    /* relational_expression  */
  YYSYMBOL_shift_expression = 131,         /* shift_expression  */
  YYSYMBOL_additive_expression = 132,      /* additive_expression  */
  YYSYMBOL_multiplicative_expression = 133, /* multiplicative_expression  */
  YYSYMBOL_cast_expression = 134,          /* cast_expression  */
  YYSYMBOL_unary_expression = 135,         /* unary_expression  */
  YYSYMBOL_postfix_expression = 136,       /* postfix_expression  */
  YYSYMBOL_arg_list_opt = 137,             /* arg_list_opt  */
  YYSYMBOL_argument_expression_list = 138, /* argument_expression_list  */
  YYSYMBOL_primary_expression = 139,       /* primary_expression  */
  YYSYMBOL_constant = 140                  /* constant  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  2
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   663

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  82
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  59
/* YYNRULES -- Number of rules.  */
#define YYNRULES  166
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  269

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   336


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   110,   110,   111,   115,   116,   122,   121,   128,   137,
     138,   142,   143,   147,   151,   156,   161,   166,   167,   171,
     173,   175,   177,   182,   183,   184,   185,   186,   190,   191,
     194,   194,   194,   194,   197,   198,   199,   200,   201,   202,
     203,   204,   210,   220,   221,   225,   226,   230,   234,   241,
     251,   252,   257,   265,   266,   267,   271,   272,   277,   277,
     283,   287,   288,   292,   293,   298,   299,   300,   301,   302,
     303,   307,   308,   312,   316,   317,   321,   322,   323,   327,
     328,   329,   333,   334,   338,   339,   343,   344,   348,   349,
     350,   351,   356,   357,   361,   362,   366,   366,   366,   367,
     367,   367,   368,   368,   368,   369,   369,   373,   374,   378,
     379,   383,   384,   388,   389,   393,   394,   398,   399,   403,
     404,   405,   409,   410,   411,   412,   413,   417,   418,   419,
     423,   424,   425,   429,   430,   431,   432,   436,   440,   441,
     442,   443,   444,   445,   446,   447,   448,   449,   450,   454,
     455,   456,   457,   458,   459,   460,   464,   465,   469,   470,
     474,   475,   476,   477,   481,   482,   483
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "TOKEN_IDENTIFIER",
  "TOKEN_INT_CONST", "TOKEN_FLOAT_CONST", "TOKEN_CHAR_CONST",
  "TOKEN_STRING_LITERAL", "TOKEN_INT", "TOKEN_FLOAT", "TOKEN_CHAR",
  "TOKEN_DOUBLE", "TOKEN_VOID", "TOKEN_LONG", "TOKEN_SHORT",
  "TOKEN_UNSIGNED", "TOKEN_SIGNED", "TOKEN_STRUCT", "TOKEN_UNION",
  "TOKEN_TYPEDEF", "TOKEN_ENUM", "TOKEN_AUTO", "TOKEN_EXTERN",
  "TOKEN_REGISTER", "TOKEN_STATIC", "TOKEN_IF", "TOKEN_ELSE", "TOKEN_DO",
  "TOKEN_WHILE", "TOKEN_FOR", "TOKEN_SWITCH", "TOKEN_CASE",
  "TOKEN_DEFAULT", "TOKEN_BREAK", "TOKEN_CONTINUE", "TOKEN_RETURN",
  "TOKEN_SIZEOF", "TOKEN_PLUS", "TOKEN_MINUS", "TOKEN_STAR", "TOKEN_SLASH",
  "TOKEN_PERCENT", "TOKEN_INC", "TOKEN_DEC", "TOKEN_EQ", "TOKEN_NE",
  "TOKEN_LT", "TOKEN_GT", "TOKEN_LE", "TOKEN_GE", "TOKEN_AND", "TOKEN_OR",
  "TOKEN_NOT", "TOKEN_ASSIGN", "TOKEN_ADD_ASSIGN", "TOKEN_SUB_ASSIGN",
  "TOKEN_MUL_ASSIGN", "TOKEN_DIV_ASSIGN", "TOKEN_MOD_ASSIGN",
  "TOKEN_AND_ASSIGN", "TOKEN_OR_ASSIGN", "TOKEN_XOR_ASSIGN",
  "TOKEN_LSHIFT_ASSIGN", "TOKEN_RSHIFT_ASSIGN", "TOKEN_BIT_AND",
  "TOKEN_BIT_NOT", "TOKEN_BIT_OR", "TOKEN_BIT_XOR", "TOKEN_LSHIFT",
  "TOKEN_RSHIFT", "TOKEN_DOT", "TOKEN_ARROW", "TOKEN_QUESTION",
  "TOKEN_SEMICOLON", "TOKEN_COMMA", "TOKEN_LPAREN", "TOKEN_RPAREN",
  "TOKEN_LBRACE", "TOKEN_RBRACE", "TOKEN_LBRACKET", "TOKEN_RBRACKET",
  "TOKEN_COLON", "$accept", "translation_unit", "external_declaration",
  "function_definition", "$@1", "declarator_func", "param_list_opt",
  "parameter_list", "parameter_declaration", "param_declarator",
  "declaration", "declaration_specifiers", "storage_class_specifier",
  "type_qualifier_list", "type_qualifier", "type_specifier",
  "init_declarator_list", "init_declarator", "declarator",
  "simple_declarator", "array_dims", "initializer_val",
  "initializer_list_inner", "compound_statement", "$@2",
  "compound_statement_noenter", "block_item_list", "block_item",
  "statement", "labeled_statement", "constant_expression",
  "expression_statement", "selection_statement", "iteration_statement",
  "for_init", "for_cond", "for_step", "jump_statement", "expression",
  "assignment_expression", "assignment_op", "conditional_expression",
  "logical_or_expression", "logical_and_expression",
  "bitwise_or_expression", "bitwise_xor_expression",
  "bitwise_and_expression", "equality_expression", "relational_expression",
  "shift_expression", "additive_expression", "multiplicative_expression",
  "cast_expression", "unary_expression", "postfix_expression",
  "arg_list_opt", "argument_expression_list", "primary_expression",
  "constant", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-174)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-41)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
    -174,   611,  -174,  -174,  -174,  -174,  -174,  -174,    40,    48,
    -174,  -174,    41,    79,  -174,  -174,  -174,  -174,  -174,  -174,
    -174,  -174,    36,   244,   244,  -174,  -174,  -174,  -174,    11,
     112,  -174,    52,   -33,  -174,    80,  -174,   244,  -174,  -174,
    -174,   -59,  -174,  -174,  -174,    33,   371,  -174,     8,   -59,
     628,  -174,  -174,  -174,  -174,  -174,  -174,  -174,   438,   543,
     543,   543,   543,   543,   543,   543,   543,   371,  -174,  -174,
    -174,   -34,    68,    72,    73,    97,    51,   -14,    43,   115,
      64,  -174,   600,    93,  -174,  -174,    87,  -174,    95,    70,
    -174,    34,   519,  -174,  -174,  -174,  -174,  -174,  -174,  -174,
    -174,  -174,     0,  -174,  -174,   -53,   543,   543,   543,   543,
     543,   543,   543,   543,   543,   543,   543,   543,   543,   543,
     543,   543,   543,   543,   543,  -174,  -174,  -174,  -174,  -174,
    -174,  -174,  -174,  -174,  -174,  -174,   543,  -174,  -174,   172,
     173,   543,   543,  -174,   101,   628,  -174,   178,  -174,  -174,
    -174,   -26,   543,  -174,    42,  -174,    68,   -55,    72,    73,
      97,    51,   -14,   -14,    43,    43,    43,    43,   115,   115,
      64,    64,  -174,  -174,  -174,  -174,  -174,  -174,  -174,   106,
     109,   -50,  -174,  -174,  -174,  -174,   110,  -174,  -174,  -174,
    -174,   543,  -174,   543,  -174,   199,  -174,  -174,  -174,   116,
     329,   117,   118,   120,   543,   104,   114,   123,   502,  -174,
    -174,  -174,  -174,    50,  -174,  -174,  -174,  -174,  -174,  -174,
    -174,  -174,    81,   543,   169,   543,   446,   543,   119,  -174,
     329,  -174,  -174,  -174,    83,  -174,  -174,    17,   124,    58,
    -174,  -174,   543,    65,   329,  -174,  -174,   275,   329,   543,
     329,   125,   127,   329,  -174,  -174,   193,    71,  -174,   543,
    -174,   329,   163,   164,   127,  -174,  -174,   329,  -174
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       2,     0,     1,    34,    35,    36,    37,    38,    32,    33,
      30,    31,     0,     0,    27,    23,    25,    26,    24,     3,
       4,     5,     0,     0,     0,    28,    20,    41,    42,    50,
       0,    18,     0,     0,    43,    45,    47,     0,    19,    29,
      22,    48,    50,     6,    17,     0,     0,    21,     0,    49,
       9,    50,    44,   160,   164,   165,   166,   162,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    46,    53,
      94,   107,   109,   111,   113,   115,   117,   119,   122,   127,
     130,   133,   137,   138,   149,   161,     0,    52,     0,    10,
      11,    16,     0,   146,   142,   137,   145,   139,   140,   141,
     144,   143,     0,    92,    56,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    96,    97,    98,    99,   100,
     101,   102,   103,   104,   105,   106,     0,   154,   155,     0,
       0,   156,     0,    51,     0,     0,    14,     0,    13,    39,
      40,     0,     0,   163,     0,    54,   110,     0,   112,   114,
     116,   118,   120,   121,   123,   124,   125,   126,   128,   129,
     131,   132,   134,   135,   136,    95,   152,   153,   158,     0,
     157,     0,    61,     7,    12,    15,     0,   147,    93,    55,
      57,     0,   151,     0,   150,     0,   148,   108,   159,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    74,
      58,    60,    63,     0,    65,    62,    64,    70,    66,    67,
      68,    69,     0,     0,     0,     0,     0,     0,     0,    73,
       0,    88,    89,    90,     0,    61,    75,     0,     0,     0,
      82,    83,    84,     0,     0,    72,    91,     0,     0,     0,
       0,     0,    85,     0,    71,    59,    76,     0,    79,    86,
      78,     0,     0,     0,    87,    77,    80,     0,    81
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -174,  -174,  -174,  -174,  -174,  -174,  -174,  -174,    94,  -174,
      -1,    21,  -174,   220,    -8,    -9,  -174,   200,  -174,  -174,
     202,   -64,  -174,  -174,  -174,  -174,    12,  -174,  -102,  -174,
    -174,    20,  -174,  -174,  -174,  -174,  -174,  -174,   -65,   -44,
    -174,  -173,  -174,   142,   141,   156,   140,   155,    57,   -15,
      55,    59,    66,   -54,  -174,  -174,  -174,  -174,  -174
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
       0,     1,    19,    20,    50,    32,    88,    89,    90,   148,
     212,   213,    23,    24,    25,    26,    33,    34,    35,    36,
      41,    68,   105,   214,   235,   183,   195,   215,   216,   217,
     228,   218,   219,   220,   242,   251,   263,   221,   222,   103,
     136,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      79,    80,    81,    82,    83,   179,   180,    84,    85
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      21,   102,    69,   104,    93,    95,    95,    97,    98,    95,
      95,    95,    86,   186,    38,    40,    39,   106,   197,   152,
      48,   154,    22,    69,   152,   155,   191,   102,    47,    39,
     194,   229,   114,   115,   116,   117,    51,   146,   107,    29,
      44,    45,   157,   -39,    27,    53,    54,    55,    56,    57,
     187,   -40,    95,    51,    95,    95,    95,    95,    95,    95,
      95,    95,    95,    95,    95,    95,    95,    95,    95,    95,
      95,    91,    30,   147,   152,    30,   153,   181,    58,   -39,
      59,    60,    28,   151,    61,    62,    -8,   -40,    87,    30,
     190,   152,   175,   248,    63,   112,   113,   178,   224,   164,
     165,   166,   167,   122,   123,   124,    64,    65,   188,    31,
      69,   118,   119,   -39,   -39,    42,   -39,    66,   108,    67,
     189,   -40,   -40,    31,   -40,    94,    96,    43,   245,    99,
     100,   101,   152,    46,   250,   137,   138,    95,   109,   152,
     110,   253,   254,   234,   145,   152,   256,   262,   258,   198,
      95,   260,   120,   121,   236,   152,   246,   152,   237,   265,
     239,   111,   243,   139,   140,   268,    91,   143,   141,   162,
     163,   144,   142,   168,   169,   176,   177,   252,   182,   170,
     171,   185,   192,   193,   257,   230,   196,   231,   172,   173,
     174,   223,   225,   226,   264,   227,   232,   238,   259,   249,
     244,   152,    53,    54,    55,    56,    57,     3,     4,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,   261,
      15,    16,    17,    18,   199,   240,   200,   201,   202,   203,
     204,   205,   206,   207,   208,    58,   266,    59,    60,   184,
     267,    61,    62,    37,    49,    52,   241,   247,   156,   158,
     160,    63,     3,     4,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    64,    65,   159,   161,     0,     0,     0,
       0,     0,   209,     0,    66,     0,   210,   211,    53,    54,
      55,    56,    57,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,    13,    14,     0,    15,    16,    17,    18,
     199,     0,   200,   201,   202,   203,   204,   205,   206,   207,
     208,    58,     0,    59,    60,     0,     0,    61,    62,     0,
       0,     0,     0,     0,     0,     0,     0,    63,     0,     0,
       0,     0,    53,    54,    55,    56,    57,     0,     0,    64,
      65,     0,     0,     0,     0,     0,     0,     0,   209,     0,
      66,     0,   210,   255,   199,     0,   200,   201,   202,   203,
     204,   205,   206,   207,   208,    58,     0,    59,    60,     0,
       0,    61,    62,     0,    53,    54,    55,    56,    57,     0,
       0,    63,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    64,    65,     0,     0,     0,     0,     0,
       0,     0,   209,     0,    66,     0,   210,    58,     0,    59,
      60,     0,     0,    61,    62,     0,     0,     0,     0,     0,
       0,     0,     0,    63,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    64,    65,     0,     0,     0,
       0,    53,    54,    55,    56,    57,    66,     0,    67,    53,
      54,    55,    56,    57,     3,     4,     5,     6,     7,     8,
       9,    10,    11,    12,    13,    14,     0,    15,    16,    17,
      18,     0,     0,     0,    58,     0,    59,    60,     0,     0,
      61,    62,    58,     0,    59,    60,     0,     0,    61,    62,
      63,     0,     0,     0,     0,     0,     0,     0,    63,     0,
       0,     0,    64,    65,     0,    53,    54,    55,    56,    57,
      64,    65,     0,    92,     0,     0,     0,     0,     0,   209,
       0,    66,    53,    54,    55,    56,    57,     3,     4,     5,
       6,     7,   149,   150,     0,     0,    12,    13,    58,     0,
      59,    60,     0,     0,    61,    62,    53,    54,    55,    56,
      57,     0,     0,     0,    63,    58,     0,    59,    60,     0,
       0,    61,    62,     0,     0,     0,    64,    65,     0,     0,
       0,    63,     0,     0,     0,   233,     0,    66,     0,    58,
       0,    59,    60,    64,    65,    61,    62,     0,     0,     0,
       0,     0,     0,     0,    66,    63,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    64,    65,     0,
       0,     2,     0,     0,     0,     0,     0,     0,    66,     3,
       4,     5,     6,     7,     8,     9,    10,    11,    12,    13,
      14,     0,    15,    16,    17,    18,     3,     4,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,     0,    15,
      16,    17,    18,   125,   126,   127,   128,   129,   130,   131,
     132,   133,   134,   135
};

static const yytype_int16 yycheck[] =
{
       1,    66,    46,    67,    58,    59,    60,    61,    62,    63,
      64,    65,     4,    39,    23,    24,    24,    51,   191,    74,
      79,    74,     1,    67,    74,    78,    81,    92,    37,    37,
      80,   204,    46,    47,    48,    49,     3,     3,    72,     3,
      73,    74,   107,     3,     3,     3,     4,     5,     6,     7,
      76,     3,   106,     3,   108,   109,   110,   111,   112,   113,
     114,   115,   116,   117,   118,   119,   120,   121,   122,   123,
     124,    50,    39,    39,    74,    39,    76,   142,    36,    39,
      38,    39,     3,    92,    42,    43,    75,    39,    80,    39,
     154,    74,   136,    76,    52,    44,    45,   141,   200,   114,
     115,   116,   117,    39,    40,    41,    64,    65,   152,    73,
     154,    68,    69,    73,    74,     3,    76,    75,    50,    77,
      78,    73,    74,    73,    76,    59,    60,    75,   230,    63,
      64,    65,    74,    53,    76,    42,    43,   191,    66,    74,
      67,    76,   244,   208,    74,    74,   248,    76,   250,   193,
     204,   253,    37,    38,    73,    74,    73,    74,   223,   261,
     225,    64,   227,    70,    71,   267,   145,    80,    75,   112,
     113,    76,    79,   118,   119,     3,     3,   242,    77,   120,
     121,     3,    76,    74,   249,    81,    76,    73,   122,   123,
     124,    75,    75,    75,   259,    75,    73,    28,    73,    75,
      81,    74,     3,     4,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    26,
      21,    22,    23,    24,    25,   226,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    73,    38,    39,   145,
      76,    42,    43,    23,    42,    45,   226,   235,   106,   108,
     110,    52,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    64,    65,   109,   111,    -1,    -1,    -1,
      -1,    -1,    73,    -1,    75,    -1,    77,    78,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    -1,    21,    22,    23,    24,
      25,    -1,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    -1,    38,    39,    -1,    -1,    42,    43,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    52,    -1,    -1,
      -1,    -1,     3,     4,     5,     6,     7,    -1,    -1,    64,
      65,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    73,    -1,
      75,    -1,    77,    78,    25,    -1,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    -1,    38,    39,    -1,
      -1,    42,    43,    -1,     3,     4,     5,     6,     7,    -1,
      -1,    52,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    64,    65,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    73,    -1,    75,    -1,    77,    36,    -1,    38,
      39,    -1,    -1,    42,    43,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    52,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    64,    65,    -1,    -1,    -1,
      -1,     3,     4,     5,     6,     7,    75,    -1,    77,     3,
       4,     5,     6,     7,     8,     9,    10,    11,    12,    13,
      14,    15,    16,    17,    18,    19,    -1,    21,    22,    23,
      24,    -1,    -1,    -1,    36,    -1,    38,    39,    -1,    -1,
      42,    43,    36,    -1,    38,    39,    -1,    -1,    42,    43,
      52,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    52,    -1,
      -1,    -1,    64,    65,    -1,     3,     4,     5,     6,     7,
      64,    65,    -1,    75,    -1,    -1,    -1,    -1,    -1,    73,
      -1,    75,     3,     4,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    -1,    -1,    17,    18,    36,    -1,
      38,    39,    -1,    -1,    42,    43,     3,     4,     5,     6,
       7,    -1,    -1,    -1,    52,    36,    -1,    38,    39,    -1,
      -1,    42,    43,    -1,    -1,    -1,    64,    65,    -1,    -1,
      -1,    52,    -1,    -1,    -1,    73,    -1,    75,    -1,    36,
      -1,    38,    39,    64,    65,    42,    43,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    75,    52,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    64,    65,    -1,
      -1,     0,    -1,    -1,    -1,    -1,    -1,    -1,    75,     8,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    -1,    21,    22,    23,    24,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    -1,    21,
      22,    23,    24,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    62,    63
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,    83,     0,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    21,    22,    23,    24,    84,
      85,    92,    93,    94,    95,    96,    97,     3,     3,     3,
      39,    73,    87,    98,    99,   100,   101,    95,    97,    96,
      97,   102,     3,    75,    73,    74,    53,    97,    79,   102,
      86,     3,    99,     3,     4,     5,     6,     7,    36,    38,
      39,    42,    43,    52,    64,    65,    75,    77,   103,   121,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,   134,   135,   136,   139,   140,     4,    80,    88,    89,
      90,    93,    75,   135,   134,   135,   134,   135,   135,   134,
     134,   134,   120,   121,   103,   104,    51,    72,    50,    66,
      67,    64,    44,    45,    46,    47,    48,    49,    68,    69,
      37,    38,    39,    40,    41,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,    63,   122,    42,    43,    70,
      71,    75,    79,    80,    76,    74,     3,    39,    91,    13,
      14,    97,    74,    76,    74,    78,   125,   120,   126,   127,
     128,   129,   130,   130,   131,   131,   131,   131,   132,   132,
     133,   133,   134,   134,   134,   121,     3,     3,   121,   137,
     138,   120,    77,   107,    90,     3,    39,    76,   121,    78,
     103,    81,    76,    74,    80,   108,    76,   123,   121,    25,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    73,
      77,    78,    92,    93,   105,   109,   110,   111,   113,   114,
     115,   119,   120,    75,   110,    75,    75,    75,   112,   123,
      81,    73,    73,    73,   120,   106,    73,   120,    28,   120,
      92,   113,   116,   120,    81,   110,    73,   108,    76,    75,
      76,   117,   120,    76,   110,    78,   110,   120,   110,    73,
     110,    26,    76,   118,   120,   110,    73,    76,   110
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_uint8 yyr1[] =
{
       0,    82,    83,    83,    84,    84,    86,    85,    87,    88,
      88,    89,    89,    90,    91,    91,    91,    92,    92,    93,
      93,    93,    93,    94,    94,    94,    94,    94,    95,    95,
      96,    96,    96,    96,    97,    97,    97,    97,    97,    97,
      97,    97,    97,    98,    98,    99,    99,   100,   101,   101,
     102,   102,   102,   103,   103,   103,   104,   104,   106,   105,
     107,   108,   108,   109,   109,   110,   110,   110,   110,   110,
     110,   111,   111,   112,   113,   113,   114,   114,   114,   115,
     115,   115,   116,   116,   117,   117,   118,   118,   119,   119,
     119,   119,   120,   120,   121,   121,   122,   122,   122,   122,
     122,   122,   122,   122,   122,   122,   122,   123,   123,   124,
     124,   125,   125,   126,   126,   127,   127,   128,   128,   129,
     129,   129,   130,   130,   130,   130,   130,   131,   131,   131,
     132,   132,   132,   133,   133,   133,   133,   134,   135,   135,
     135,   135,   135,   135,   135,   135,   135,   135,   135,   136,
     136,   136,   136,   136,   136,   136,   137,   137,   138,   138,
     139,   139,   139,   139,   140,   140,   140
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     0,     2,     1,     1,     0,     7,     1,     0,
       1,     1,     3,     2,     1,     2,     0,     3,     2,     2,
       1,     3,     2,     1,     1,     1,     1,     1,     1,     2,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     2,     2,     1,     3,     1,     3,     1,     2,     3,
       0,     4,     3,     1,     3,     4,     1,     3,     0,     4,
       3,     0,     2,     1,     1,     1,     1,     1,     1,     1,
       1,     4,     3,     1,     1,     2,     5,     7,     5,     5,
       7,     8,     1,     1,     0,     1,     0,     1,     2,     2,
       2,     3,     1,     3,     1,     3,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     5,     1,
       3,     1,     3,     1,     3,     1,     3,     1,     3,     1,
       3,     3,     1,     3,     3,     3,     3,     1,     3,     3,
       1,     3,     3,     1,     3,     3,     3,     1,     1,     2,
       2,     2,     2,     2,     2,     2,     2,     4,     5,     1,
       4,     4,     3,     3,     2,     2,     0,     1,     1,     3,
       1,     1,     1,     3,     1,     1,     1
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 6: /* $@1: %empty  */
#line 122 "parser.y"
                     { sym_enter_scope(); }
#line 1540 "parser.tab.c"
    break;

  case 7: /* function_definition: declaration_specifiers declarator_func TOKEN_LPAREN $@1 param_list_opt TOKEN_RPAREN compound_statement_noenter  */
#line 124 "parser.y"
        { sym_exit_scope(); }
#line 1546 "parser.tab.c"
    break;

  case 8: /* declarator_func: TOKEN_IDENTIFIER  */
#line 129 "parser.y"
        {
            /* register function in outer scope */
            sym_add((yyvsp[0].str), KIND_FUNCTION, cur_base_type, 0,
                    0, NULL, cur_storage, yylineno, 1, "");
        }
#line 1556 "parser.tab.c"
    break;

  case 14: /* param_declarator: TOKEN_IDENTIFIER  */
#line 152 "parser.y"
        {
            sym_add((yyvsp[0].str), KIND_PARAMETER, cur_base_type, 0,
                    0, NULL, STORAGE_AUTO, yylineno, 1, "");
        }
#line 1565 "parser.tab.c"
    break;

  case 15: /* param_declarator: TOKEN_STAR TOKEN_IDENTIFIER  */
#line 157 "parser.y"
        {
            sym_add((yyvsp[0].str), KIND_PARAMETER, cur_base_type, 1,
                    0, NULL, STORAGE_AUTO, yylineno, 1, "");
        }
#line 1574 "parser.tab.c"
    break;

  case 19: /* declaration_specifiers: storage_class_specifier type_specifier  */
#line 172 "parser.y"
        { strncpy(cur_base_type, (yyvsp[0].str), 63); }
#line 1580 "parser.tab.c"
    break;

  case 20: /* declaration_specifiers: type_specifier  */
#line 174 "parser.y"
        { strncpy(cur_base_type, (yyvsp[0].str), 63); cur_storage = STORAGE_AUTO; }
#line 1586 "parser.tab.c"
    break;

  case 21: /* declaration_specifiers: storage_class_specifier type_qualifier_list type_specifier  */
#line 176 "parser.y"
        { strncpy(cur_base_type, (yyvsp[0].str), 63); }
#line 1592 "parser.tab.c"
    break;

  case 22: /* declaration_specifiers: type_qualifier_list type_specifier  */
#line 178 "parser.y"
        { strncpy(cur_base_type, (yyvsp[0].str), 63); cur_storage = STORAGE_AUTO; }
#line 1598 "parser.tab.c"
    break;

  case 23: /* storage_class_specifier: TOKEN_AUTO  */
#line 182 "parser.y"
                     { cur_storage = STORAGE_AUTO; }
#line 1604 "parser.tab.c"
    break;

  case 24: /* storage_class_specifier: TOKEN_STATIC  */
#line 183 "parser.y"
                     { cur_storage = STORAGE_STATIC; }
#line 1610 "parser.tab.c"
    break;

  case 25: /* storage_class_specifier: TOKEN_EXTERN  */
#line 184 "parser.y"
                     { cur_storage = STORAGE_EXTERN; }
#line 1616 "parser.tab.c"
    break;

  case 26: /* storage_class_specifier: TOKEN_REGISTER  */
#line 185 "parser.y"
                     { cur_storage = STORAGE_REGISTER; }
#line 1622 "parser.tab.c"
    break;

  case 27: /* storage_class_specifier: TOKEN_TYPEDEF  */
#line 186 "parser.y"
                     { cur_storage = STORAGE_AUTO; }
#line 1628 "parser.tab.c"
    break;

  case 28: /* type_qualifier_list: type_qualifier  */
#line 190 "parser.y"
                     { (yyval.str) [0] = '\0'; }
#line 1634 "parser.tab.c"
    break;

  case 29: /* type_qualifier_list: type_qualifier_list type_qualifier  */
#line 191 "parser.y"
                                         { (yyval.str) [0] = '\0'; }
#line 1640 "parser.tab.c"
    break;

  case 34: /* type_specifier: TOKEN_INT  */
#line 197 "parser.y"
                   { strncpy((yyval.str), "int",    63); }
#line 1646 "parser.tab.c"
    break;

  case 35: /* type_specifier: TOKEN_FLOAT  */
#line 198 "parser.y"
                   { strncpy((yyval.str), "float",  63); }
#line 1652 "parser.tab.c"
    break;

  case 36: /* type_specifier: TOKEN_CHAR  */
#line 199 "parser.y"
                   { strncpy((yyval.str), "char",   63); }
#line 1658 "parser.tab.c"
    break;

  case 37: /* type_specifier: TOKEN_DOUBLE  */
#line 200 "parser.y"
                   { strncpy((yyval.str), "double", 63); }
#line 1664 "parser.tab.c"
    break;

  case 38: /* type_specifier: TOKEN_VOID  */
#line 201 "parser.y"
                   { strncpy((yyval.str), "void",   63); }
#line 1670 "parser.tab.c"
    break;

  case 39: /* type_specifier: TOKEN_LONG  */
#line 202 "parser.y"
                   { strncpy((yyval.str), "long",   63); }
#line 1676 "parser.tab.c"
    break;

  case 40: /* type_specifier: TOKEN_SHORT  */
#line 203 "parser.y"
                   { strncpy((yyval.str), "short",  63); }
#line 1682 "parser.tab.c"
    break;

  case 41: /* type_specifier: TOKEN_STRUCT TOKEN_IDENTIFIER  */
#line 205 "parser.y"
        {
            snprintf((yyval.str), sizeof((yyval.str)), "struct %.50s", (yyvsp[0].str));
            sym_add((yyvsp[0].str), KIND_STRUCT_TAG, "struct", 0,
                    0, NULL, STORAGE_AUTO, yylineno, 1, "");
        }
#line 1692 "parser.tab.c"
    break;

  case 42: /* type_specifier: TOKEN_UNION TOKEN_IDENTIFIER  */
#line 211 "parser.y"
        {
            snprintf((yyval.str), sizeof((yyval.str)), "union %.50s", (yyvsp[0].str));
            sym_add((yyvsp[0].str), KIND_UNION_TAG, "union", 0,
                    0, NULL, STORAGE_AUTO, yylineno, 1, "");
        }
#line 1702 "parser.tab.c"
    break;

  case 47: /* declarator: simple_declarator  */
#line 230 "parser.y"
                        { (yyval.str) [0] = '\0'; }
#line 1708 "parser.tab.c"
    break;

  case 48: /* simple_declarator: TOKEN_IDENTIFIER array_dims  */
#line 235 "parser.y"
        {
            sym_add((yyvsp[-1].str), KIND_VARIABLE, cur_base_type, decl_ptr,
                    decl_ndim, decl_dims, cur_storage, yylineno, 1,
                    decl_val);
            decl_ptr = 0; decl_ndim = 0; decl_val[0] = '\0';
        }
#line 1719 "parser.tab.c"
    break;

  case 49: /* simple_declarator: TOKEN_STAR TOKEN_IDENTIFIER array_dims  */
#line 242 "parser.y"
        {
            sym_add((yyvsp[-1].str), KIND_VARIABLE, cur_base_type, 1,
                    decl_ndim, decl_dims, cur_storage, yylineno, 1,
                    decl_val);
            decl_ptr = 0; decl_ndim = 0; decl_val[0] = '\0';
        }
#line 1730 "parser.tab.c"
    break;

  case 50: /* array_dims: %empty  */
#line 251 "parser.y"
                          { decl_ndim = 0; }
#line 1736 "parser.tab.c"
    break;

  case 51: /* array_dims: array_dims TOKEN_LBRACKET TOKEN_INT_CONST TOKEN_RBRACKET  */
#line 253 "parser.y"
        {
            if (decl_ndim < MAX_DIMS)
                decl_dims[decl_ndim++] = atoi((yyvsp[-1].str));
        }
#line 1745 "parser.tab.c"
    break;

  case 52: /* array_dims: array_dims TOKEN_LBRACKET TOKEN_RBRACKET  */
#line 258 "parser.y"
        {
            if (decl_ndim < MAX_DIMS)
                decl_dims[decl_ndim++] = 0;
        }
#line 1754 "parser.tab.c"
    break;

  case 58: /* $@2: %empty  */
#line 277 "parser.y"
                   { sym_enter_scope(); }
#line 1760 "parser.tab.c"
    break;

  case 59: /* compound_statement: TOKEN_LBRACE $@2 block_item_list TOKEN_RBRACE  */
#line 278 "parser.y"
        { sym_exit_scope(); }
#line 1766 "parser.tab.c"
    break;

  case 160: /* primary_expression: TOKEN_IDENTIFIER  */
#line 474 "parser.y"
                         { strncpy((yyval.str), (yyvsp[0].str), 63); }
#line 1772 "parser.tab.c"
    break;

  case 161: /* primary_expression: constant  */
#line 475 "parser.y"
                         { strncpy((yyval.str), (yyvsp[0].str), 63); }
#line 1778 "parser.tab.c"
    break;

  case 162: /* primary_expression: TOKEN_STRING_LITERAL  */
#line 476 "parser.y"
                           { strncpy((yyval.str), (yyvsp[0].str), 63); }
#line 1784 "parser.tab.c"
    break;

  case 163: /* primary_expression: TOKEN_LPAREN expression TOKEN_RPAREN  */
#line 477 "parser.y"
                                           { (yyval.str) [0] = '\0'; }
#line 1790 "parser.tab.c"
    break;

  case 164: /* constant: TOKEN_INT_CONST  */
#line 481 "parser.y"
                         { strncpy((yyval.str), (yyvsp[0].str), 63); }
#line 1796 "parser.tab.c"
    break;

  case 165: /* constant: TOKEN_FLOAT_CONST  */
#line 482 "parser.y"
                         { strncpy((yyval.str), (yyvsp[0].str), 63); }
#line 1802 "parser.tab.c"
    break;

  case 166: /* constant: TOKEN_CHAR_CONST  */
#line 483 "parser.y"
                         { strncpy((yyval.str), (yyvsp[0].str), 63); }
#line 1808 "parser.tab.c"
    break;


#line 1812 "parser.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 487 "parser.y"


/* ============================================================ */
void yyerror(const char *s) {
    syntax_error = 1;
    fprintf(stderr, "Error: %s at line %d (token: '%s')\n",
            s, yylineno, yytext);
}

int main(int argc, char **argv) {
    extern FILE *yyin;

    sym_init();

    if (argc > 1) {
        FILE *f = fopen(argv[1], "r");
        if (!f) { fprintf(stderr, "Cannot open %s\n", argv[1]); return 1; }
        yyin = f;
    }

    yyparse();

    sym_print_table();

    if (argc > 1) fclose(yyin);
    yylex_destroy();
    return syntax_error ? 1 : 0;
}
