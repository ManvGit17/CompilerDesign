/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_PARSER_TAB_H_INCLUDED
# define YY_YY_PARSER_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    TOKEN_IDENTIFIER = 258,        /* TOKEN_IDENTIFIER  */
    TOKEN_INT_CONST = 259,         /* TOKEN_INT_CONST  */
    TOKEN_FLOAT_CONST = 260,       /* TOKEN_FLOAT_CONST  */
    TOKEN_CHAR_CONST = 261,        /* TOKEN_CHAR_CONST  */
    TOKEN_STRING_LITERAL = 262,    /* TOKEN_STRING_LITERAL  */
    TOKEN_INT = 263,               /* TOKEN_INT  */
    TOKEN_FLOAT = 264,             /* TOKEN_FLOAT  */
    TOKEN_CHAR = 265,              /* TOKEN_CHAR  */
    TOKEN_DOUBLE = 266,            /* TOKEN_DOUBLE  */
    TOKEN_VOID = 267,              /* TOKEN_VOID  */
    TOKEN_LONG = 268,              /* TOKEN_LONG  */
    TOKEN_SHORT = 269,             /* TOKEN_SHORT  */
    TOKEN_UNSIGNED = 270,          /* TOKEN_UNSIGNED  */
    TOKEN_SIGNED = 271,            /* TOKEN_SIGNED  */
    TOKEN_STRUCT = 272,            /* TOKEN_STRUCT  */
    TOKEN_UNION = 273,             /* TOKEN_UNION  */
    TOKEN_TYPEDEF = 274,           /* TOKEN_TYPEDEF  */
    TOKEN_ENUM = 275,              /* TOKEN_ENUM  */
    TOKEN_AUTO = 276,              /* TOKEN_AUTO  */
    TOKEN_EXTERN = 277,            /* TOKEN_EXTERN  */
    TOKEN_REGISTER = 278,          /* TOKEN_REGISTER  */
    TOKEN_STATIC = 279,            /* TOKEN_STATIC  */
    TOKEN_IF = 280,                /* TOKEN_IF  */
    TOKEN_ELSE = 281,              /* TOKEN_ELSE  */
    TOKEN_DO = 282,                /* TOKEN_DO  */
    TOKEN_WHILE = 283,             /* TOKEN_WHILE  */
    TOKEN_FOR = 284,               /* TOKEN_FOR  */
    TOKEN_SWITCH = 285,            /* TOKEN_SWITCH  */
    TOKEN_CASE = 286,              /* TOKEN_CASE  */
    TOKEN_DEFAULT = 287,           /* TOKEN_DEFAULT  */
    TOKEN_BREAK = 288,             /* TOKEN_BREAK  */
    TOKEN_CONTINUE = 289,          /* TOKEN_CONTINUE  */
    TOKEN_RETURN = 290,            /* TOKEN_RETURN  */
    TOKEN_SIZEOF = 291,            /* TOKEN_SIZEOF  */
    TOKEN_PLUS = 292,              /* TOKEN_PLUS  */
    TOKEN_MINUS = 293,             /* TOKEN_MINUS  */
    TOKEN_STAR = 294,              /* TOKEN_STAR  */
    TOKEN_SLASH = 295,             /* TOKEN_SLASH  */
    TOKEN_PERCENT = 296,           /* TOKEN_PERCENT  */
    TOKEN_INC = 297,               /* TOKEN_INC  */
    TOKEN_DEC = 298,               /* TOKEN_DEC  */
    TOKEN_EQ = 299,                /* TOKEN_EQ  */
    TOKEN_NE = 300,                /* TOKEN_NE  */
    TOKEN_LT = 301,                /* TOKEN_LT  */
    TOKEN_GT = 302,                /* TOKEN_GT  */
    TOKEN_LE = 303,                /* TOKEN_LE  */
    TOKEN_GE = 304,                /* TOKEN_GE  */
    TOKEN_AND = 305,               /* TOKEN_AND  */
    TOKEN_OR = 306,                /* TOKEN_OR  */
    TOKEN_NOT = 307,               /* TOKEN_NOT  */
    TOKEN_ASSIGN = 308,            /* TOKEN_ASSIGN  */
    TOKEN_ADD_ASSIGN = 309,        /* TOKEN_ADD_ASSIGN  */
    TOKEN_SUB_ASSIGN = 310,        /* TOKEN_SUB_ASSIGN  */
    TOKEN_MUL_ASSIGN = 311,        /* TOKEN_MUL_ASSIGN  */
    TOKEN_DIV_ASSIGN = 312,        /* TOKEN_DIV_ASSIGN  */
    TOKEN_MOD_ASSIGN = 313,        /* TOKEN_MOD_ASSIGN  */
    TOKEN_AND_ASSIGN = 314,        /* TOKEN_AND_ASSIGN  */
    TOKEN_OR_ASSIGN = 315,         /* TOKEN_OR_ASSIGN  */
    TOKEN_XOR_ASSIGN = 316,        /* TOKEN_XOR_ASSIGN  */
    TOKEN_LSHIFT_ASSIGN = 317,     /* TOKEN_LSHIFT_ASSIGN  */
    TOKEN_RSHIFT_ASSIGN = 318,     /* TOKEN_RSHIFT_ASSIGN  */
    TOKEN_BIT_AND = 319,           /* TOKEN_BIT_AND  */
    TOKEN_BIT_NOT = 320,           /* TOKEN_BIT_NOT  */
    TOKEN_BIT_OR = 321,            /* TOKEN_BIT_OR  */
    TOKEN_BIT_XOR = 322,           /* TOKEN_BIT_XOR  */
    TOKEN_LSHIFT = 323,            /* TOKEN_LSHIFT  */
    TOKEN_RSHIFT = 324,            /* TOKEN_RSHIFT  */
    TOKEN_DOT = 325,               /* TOKEN_DOT  */
    TOKEN_ARROW = 326,             /* TOKEN_ARROW  */
    TOKEN_QUESTION = 327,          /* TOKEN_QUESTION  */
    TOKEN_SEMICOLON = 328,         /* TOKEN_SEMICOLON  */
    TOKEN_COMMA = 329,             /* TOKEN_COMMA  */
    TOKEN_LPAREN = 330,            /* TOKEN_LPAREN  */
    TOKEN_RPAREN = 331,            /* TOKEN_RPAREN  */
    TOKEN_LBRACE = 332,            /* TOKEN_LBRACE  */
    TOKEN_RBRACE = 333,            /* TOKEN_RBRACE  */
    TOKEN_LBRACKET = 334,          /* TOKEN_LBRACKET  */
    TOKEN_RBRACKET = 335,          /* TOKEN_RBRACKET  */
    TOKEN_COLON = 336              /* TOKEN_COLON  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 44 "parser.y"

    char str[64];
    int  ival;

#line 150 "parser.tab.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_PARSER_TAB_H_INCLUDED  */
